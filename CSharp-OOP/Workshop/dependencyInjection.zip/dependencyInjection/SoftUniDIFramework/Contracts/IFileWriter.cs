﻿namespace SoftUniDIFramework.Contracts
{
    public interface IFileWriter : IWriter
    {
    }
}
