﻿namespace SoftUniDIFramework.Contracts
{
    public interface IConsoleWriter : IWriter
    {
    }
}
