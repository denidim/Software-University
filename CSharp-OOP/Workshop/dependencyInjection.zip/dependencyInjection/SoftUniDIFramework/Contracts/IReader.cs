﻿namespace SoftUniDIFramework.Contracts
{
    public interface IReader
    {
        string Read();
    }
}
