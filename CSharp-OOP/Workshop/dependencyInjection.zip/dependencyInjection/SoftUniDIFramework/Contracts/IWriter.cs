﻿namespace SoftUniDIFramework.Contracts
{
    public interface IWriter
    {
        void Write(string text);
    }
}
