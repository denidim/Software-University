﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=BookShopExamPrep;User Id=sa;Password=mssqlDB1;";
    }
}