﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Artillery.DataProcessor.ImportDto
{
    public class JsonImportCountriesIdDto
    {
        public int Id { get; set; }
    }
}
